#!/bin/bash
if [ -f "/usr/bin/teamviewer" ];then
    echo "Starting TeamViewer"
    sudo teamviewer daemon start
    sleep 3
fi
