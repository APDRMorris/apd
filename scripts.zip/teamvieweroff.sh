#!/bin/bash
if [ -f "/usr/bin/teamviewer" ];then
    echo "Stopping TeamViewer"
    sudo teamviewer daemon stop
    sleep 3
fi
