#!/bin/bash
wget -b -c -O $1 -o $2 --header="$3" --header="$4" $5
