#!/bin/bash
hostname -I
exit 0
