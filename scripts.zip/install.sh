#!/bin/bash
sudo dpkg --configure -a
sudo apt install -y $1
