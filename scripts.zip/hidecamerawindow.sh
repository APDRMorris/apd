#!/bin/bash
wincam=`xdotool search --name "^AirPro Auggie Camera$"`

xprop -name "AirPro Auggie Camera" -format _MOTIF_WM_HINTS 32c -set _MOTIF_WM_HINTS 2

wmctrl -i -r $wincam -e 0,94,0,835,470
wmctrl -i -r $wincam -b remove,above
wmctrl -i -r $wincam -b add,below

exit 0

