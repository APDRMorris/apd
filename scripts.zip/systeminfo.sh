#!/bin/bash
test -f /sys/class/net/wlo1/address && cat /sys/class/net/wlo1/address && exit 0
test -f /sys/class/net/wlo2/address && cat /sys/class/net/wlo2/address && exit 0
exit 0
