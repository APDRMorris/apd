#!/bin/bash
shutdown -r --no-wall 0
exit 0
