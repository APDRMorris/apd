#!/bin/bash
rm $1/auggie_*.deb $1/wget-log $1/wget-log.*
exit 0
